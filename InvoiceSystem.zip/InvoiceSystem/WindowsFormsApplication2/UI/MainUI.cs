﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication2.Model;
using WindowsFormsApplication2.Properties;

namespace WindowsFormsApplication2
{
    public partial class MainUI : Form
    {
        List<ProductEntry> productEntries = new List<ProductEntry>();

        private int numberOfItemsPerPage = 0;
        private int numberOfItemsPrinted = 0;
        public MainUI()
        {
            InitializeComponent();
        }

        private void productAddButton_Click(object sender, EventArgs e)
        {
            if (IsValidated())
            {
                ProductEntry newProductEntry = new ProductEntry();
                if (rateTextBox.Text != String.Empty)
                {
                    newProductEntry.Rate = rateTextBox.Text.Trim().ToString();
                }
                else
                {
                    newProductEntry.Rate = Convert.ToString('0');
                }
                newProductEntry.ProductName = productNameTextBox.Text.Trim();
                newProductEntry.Quantity = Convert.ToInt32(quantityTextBox.Text.Trim());
                newProductEntry.TotalAmount = Convert.ToInt32(quantityTextBox.Text.Trim())*
                                              Convert.ToInt32(newProductEntry.Rate);

                //ProductEntry aProductEntry = new ProductEntry()
                //{
                //    ProductName = productNameTextBox.Text.Trim(),
                //    Quantity = Convert.ToInt32(quantityTextBox.Text.Trim()),
                //    Rate = Convert.ToInt32(rateTextBox.Text.Trim()),
                //    TotalAmount = Convert.ToInt32(quantityTextBox.Text.Trim()) * Convert.ToInt32(rateTextBox.Text.Trim())
                //};

                productEntries.Add(newProductEntry);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = productEntries;

                double totalAmount = productEntries.Sum(x => x.TotalAmount);
                totalPricetextBox.Text = totalAmount.ToString();

                productNameTextBox.Clear();
                quantityTextBox.Clear();
                //perTextBox.Clear();
                rateTextBox.Clear();

                customerNameTextBox.Enabled = false;
                customerAddressTextBox.Enabled = false;
                customerContactTextBox.Enabled = false;

                productNameTextBox.Focus();
            }

        }

        private bool IsValidated()
        {
            if (customerNameTextBox.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Customer Name Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                customerNameTextBox.Focus();
                return false;
            }
            if (customerAddressTextBox.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Customer Address Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                customerAddressTextBox.Focus();
                return false;
            }
            if (customerContactTextBox.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Customer Contact No. Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                customerContactTextBox.Focus();
                return false;
            }
            if (productNameTextBox.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Product Name Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                productNameTextBox.Focus();
                return false;
            }
            if (quantityTextBox.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Quantity Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                quantityTextBox.Focus();
                return false;
            }
            else
            {
                int tempQuantity;
                bool isNumeric = int.TryParse(quantityTextBox.Text.Trim(), out tempQuantity);

                if (!isNumeric)
                {
                    MessageBox.Show("Quantity should be Numeric", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    quantityTextBox.Clear();
                    quantityTextBox.Focus();
                    return false;
                }
            }
            //if (perTextBox.Text.Trim() == String.Empty)
            //{
            //    MessageBox.Show("Per Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    perTextBox.Focus();
            //    return false;
            //}
            //if (rateTextBox.Text.Trim() == String.Empty)
            //{
            //    MessageBox.Show("Rate Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    rateTextBox.Focus();
            //    return false;
            //}
            //else
            //{
            //    int n;
            //    bool isNumeric = int.TryParse(rateTextBox.Text.Trim(), out n);

            //    if (!isNumeric)
            //    {
            //        MessageBox.Show("Rate should be Numeric", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        rateTextBox.Clear();
            //        rateTextBox.Focus();
            //        return false;
            //    }
            //}
            
            return true;
        }


        private void resetButton_Click(object sender, EventArgs e)
        {
            customerNameTextBox.Clear();
            customerAddressTextBox.Clear();
            customerContactTextBox.Clear();
            productNameTextBox.Clear();
            quantityTextBox.Clear();
            //perTextBox.Clear();
            rateTextBox.Clear();
            totalPricetextBox.Text = "0";

            dataGridView1.DataSource = null;
            productEntries.Clear();

            customerNameTextBox.Enabled = true;
            customerAddressTextBox.Enabled = true;
            customerContactTextBox.Enabled = true;
        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                var hti = dataGridView1.HitTest(e.X, e.Y);
                dataGridView1.Rows[hti.RowIndex].Selected = true;
                
                contextMenuStrip1.Show(dataGridView1, e.X, e.Y);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;

            productEntries.RemoveAt(index);

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productEntries;

            double totalAmount = productEntries.Sum(x => x.TotalAmount);
            totalPricetextBox.Text = totalAmount.ToString();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Image image = Resources.title3;

            e.Graphics.DrawImage(image, 0, 0, image.Width, image.Height);

            e.Graphics.DrawString("Date: " + DateTime.Now.ToShortDateString()  , new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 210));
            e.Graphics.DrawString("Customer Name: " + customerNameTextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 240));
            e.Graphics.DrawString("Customer Address: " + customerAddressTextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 270));
            e.Graphics.DrawString("Contact No: " + customerContactTextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 300));
            e.Graphics.DrawString("Bill", new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(375, 320));            
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 340));
            e.Graphics.DrawString("Product Name", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(30, 360));
            e.Graphics.DrawString("Quantity", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(380, 360));
            //e.Graphics.DrawString("Per", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(520, 340));
            e.Graphics.DrawString("Rate", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(600, 360));
            e.Graphics.DrawString("Amount", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(720, 360));
            e.Graphics.DrawString("--------------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, 380));

            int yPosition = 400;

            for(int i = numberOfItemsPrinted; i < productEntries.Count; i++)
            {
                numberOfItemsPerPage++;

                if (numberOfItemsPerPage <= 18)
                {
                    numberOfItemsPrinted++;

                    if (numberOfItemsPrinted <= productEntries.Count)
                    {
                        e.Graphics.DrawString(productEntries[i].ProductName, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(30, yPosition));
                        e.Graphics.DrawString(productEntries[i].Quantity.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(410, yPosition));
                        //e.Graphics.DrawString(productEntries[i].Per, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(520, yPosition));
                        e.Graphics.DrawString(productEntries[i].Rate.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(630, yPosition));
                        e.Graphics.DrawString(productEntries[i].TotalAmount.ToString(), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(730, yPosition));

                        yPosition = yPosition + 30;
                    }
                    else
                    {
                        e.HasMorePages = false;
                    }
                    
                }
                else
                {
                    numberOfItemsPerPage = 0;
                    e.HasMorePages = true;
                    return;
                }
                
            }

            e.Graphics.DrawString("--------------------------------------------------------------------------------------------------------------------------------------------", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, yPosition));

            e.Graphics.DrawString("Total Price: " + totalPricetextBox.Text.Trim() + "TK.", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(630, yPosition+30));
            e.Graphics.DrawString("___________________________", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(560, yPosition+100));
            e.Graphics.DrawString("___________________________", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new Point(25, yPosition+100));
            e.Graphics.DrawString("Sumon Bhuiyan", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(630, yPosition+120));
            e.Graphics.DrawString("Received By", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(100, yPosition+120));
            e.Graphics.DrawString("Proprietor", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(660, yPosition+140));

            //reset the variables;

            numberOfItemsPerPage = 0;
            numberOfItemsPrinted = 0;
        }

        

        private void printViewButton_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printButton_Click(object sender, EventArgs e)
        {
            printDocument1.Print();  
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
