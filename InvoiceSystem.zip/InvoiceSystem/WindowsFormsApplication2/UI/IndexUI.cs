﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2.UI
{
    public partial class IndexUI : Form
    {
        public IndexUI()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainUI form = new MainUI();
            form.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            AboutUI aboutForm = new AboutUI();
            aboutForm.Show();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void quotationButton_Click(object sender, EventArgs e)
        {
            QuotationUI quotationUi = new QuotationUI();
            quotationUi.Show();
        }
    }
}
