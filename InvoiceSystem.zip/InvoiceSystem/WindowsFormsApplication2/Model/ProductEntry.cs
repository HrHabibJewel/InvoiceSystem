﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2.Model
{
    class ProductEntry
    {
        [DisplayName("Product Name")]
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public string Per { get; set; }
        public string Rate { get; set; }
        //public int Amount { get; set; }

        [DisplayName("Total Amount")]
        public double TotalAmount { get; set; }

    }
}
