﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2.Model
{
    class QuotationEntry
    {
        [DisplayName("Referance")]
        public string ReferanceName { get; set; }
        [DisplayName("Product Name")]
        public string ProductName { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public string UnitPrice { get; set; }
        [DisplayName("Total Price")]
        public double TotalPrice { get; set; }
    }
}
